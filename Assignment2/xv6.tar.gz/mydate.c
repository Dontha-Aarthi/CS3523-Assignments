#include "types.h"
#include "date.h"
#include "user.h"



int
main(int argc, char *argv[])
{
  struct rtcdate r;
  
  if(mydate(&r))
  {
  	printf(2,"date failed\n");
  	exit();
  }
  
  printf(1,"Date: %d-%d-%d\n", r.day, r.month, r.year);
  printf(1,"Time: %d:%d:%d\n", r.hour, r.minute, r.second);

  exit();
}
