#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

int 
sys_pgtPrint(void)
{
	pde_t* pgd, pgde; // pgd-page directory, pgde-page directory entry
	pte_t* pgt, pgte; //pgt-page table, pgte-page table entry 

	pgd = myproc()->pgdir;
	
	for(int i = 0; i < NPDENTRIES; i++)
	{
		pgde = pgd[i];
		if((pgde & PTE_P) && (pgde & PTE_U))
		{
			pgt = (pte_t*)P2V(PTE_ADDR(pgde));
			for(int j = 0; j < NPTENTRIES; j++)
			{
				pgte = pgt[j];
				if((pgte & PTE_P) && (pgte & PTE_U))
					cprintf("Entry Number: %d, Virtual Address: %x, Physical Address: %x\n", j, (i << 22) | (j << 12), PTE_ADDR(pgte));
			}	
		}
	}	
	return 0;
}
