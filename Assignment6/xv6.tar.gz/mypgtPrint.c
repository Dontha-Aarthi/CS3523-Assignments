#include "types.h"
#include "user.h"

#define N 10000

//int global_array[N];

int
main(int argc, char *argv[])
{
	int glob[N]; 
	for (int i=1;i<N;i++)
	{
		glob[i]=glob[i-1];
	}
			
	if(pgtPrint() != 0){
		printf(2,"system call failed\n");
	}

 	exit();
}
