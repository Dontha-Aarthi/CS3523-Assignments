#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char *argv[])
{

  int priority;
  if(argc < 2){
    printf(2,"please enter 2 arguments, 1.syscall, 2.priority\n");
    exit();
  }
  priority = atoi(argv[1]);
  if (priority < 0 || priority > 9){
    printf(2,"Invalid priority!\n");
    exit();
  }

  printf(1,"Before changing priority of current process:\n");
  printPriority();
  
  setPriority(priority);
  printf(1,"\nAfter changing priority of current process:\n");
  printPriority();
  exit();
}